#!/usr/bin/env bash
# 依次执行：拉取签名 -> 本地验签（可选一键演示）
set -euo pipefail
cd "$(dirname "$0")"
python3 fetch_signature.py
python3 verify_signature.py
